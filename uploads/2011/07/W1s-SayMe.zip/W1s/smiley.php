<div id="toolBar">  
<?php SayMeCommentSmilies();?> 
<a class="strong" title="粗体" href="javascript: SIMPALED.Editor.strong();"></a> 
<a class="em" title="斜体" href="javascript: SIMPALED.Editor.em();"></a> 
<a class="del" title="删除线" href="javascript: SIMPALED.Editor.del();"></a> 
<a class="underline" title="下划线" href="javascript: SIMPALED.Editor.underline();"></a> 
<a class="ahref" title="超链接" href="javascript: SIMPALED.Editor.ahref();"></a>  
<a class="code" title="Code" href="javascript: SIMPALED.Editor.code();"></a>
<a class="syntax" title="syntax" href="javascript: SIMPALED.Editor.syntax();"></a>
<a class="bquote" title="插入引用" href="javascript: SIMPALED.Editor.quote();"></a> 
<a class="clearFormat" title="去除格式" href="javascript: SIMPALED.Editor.clear();"></a> 
<a class="checknum" title="字数统计" href="javascript: SIMPALED.Editor.countWords();"></a>
<a class="resetarea" title="清空输入" href="javascript: SIMPALED.Editor.empty();"></a> 
</div>