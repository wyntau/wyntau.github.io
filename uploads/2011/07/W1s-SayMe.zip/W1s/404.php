
<?php get_header(); ?>
  <div id="main">

<div id="single">
<div id="single_area"></div>
<div class="showdow_bl">
<div class="showdow_br"><div class="showdow_b"></div></div></div>
<div class="entry" >

<h1 class="post-title">404... <?php _e('Sorry, no such page.'); ?></h1>
	
	<div class="single-entry"><p>哦也，这儿啥也没有？刷新看看还有什么。</p>
<p><img src="<?php bloginfo('stylesheet_directory'); ?>/img/404/<?php echo rand(1,4);?>.jpg" height="400px" width="400px" alt="" style="display:block; margin:50px auto;"/></p>

	</div>
</div>
</div>

<?php get_footer(); ?>  