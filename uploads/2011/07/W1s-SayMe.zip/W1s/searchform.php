<form method="get" id="searchform" action="<?php echo $_SERVER['PHP_SELF']; ?>" >
 <div id="searchbox">
 <input type="submit" id="searchsubmit" value="" />
   <input type="text" value="搜索..." name="s" id="s" onfocus="if (this.value == '搜索...') {this.value = '';}" onblur="if (this.value == '') {this.value = '搜索...';}"/>
  
 </div>
</form>
