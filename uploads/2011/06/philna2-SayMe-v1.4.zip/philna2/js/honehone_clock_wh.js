function themeurl() {
        var i = 0,
        got = -1,
        url,
        len = document.getElementsByTagName('link').length;
        while (i <= len && got == -1) {
            url = document.getElementsByTagName('link')[i].href;
            got = url.indexOf('/style.css');
            i++
        }
        return url.replace(/\/style.css.*/g, "")
    };
var swfUrl = themeurl();
var swfTitle = "honehoneclock";
swfUrl+="/swf/honehone_clock_wh.swf";
LoadBlogParts();
function LoadBlogParts(){
	var sUrl = swfUrl;
	var sHtml = "";
	sHtml += '<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" width="160" height="70" id="' + swfTitle + '" align="middle">';
	sHtml += '<param name="allowScriptAccess" value="always" />';
	sHtml += '<param name="movie" value="' + sUrl + '" />';
	sHtml += '<param name="quality" value="high" />';
	sHtml += '<param name="bgcolor" value="#ffffff" />';
	sHtml += '<param name="wmode" value="transparent" />';
	sHtml += '<embed wmode="transparent" src="' + sUrl + '" quality="high" bgcolor="#ffffff" width="160" height="70" name="' + swfTitle + '" align="middle" allowScriptAccess="always" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />';
	sHtml += '</object>';
	document.write(sHtml);
}
