$(function(){
//Your js functions goes here
//Have a good time!!





});
