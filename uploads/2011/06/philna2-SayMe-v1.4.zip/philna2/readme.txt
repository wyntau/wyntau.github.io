﻿Develop environment
	PHP 5.3.0
	Apache 2.2.12 (Win32)
	MySQL 5.1.37
	WordPress 2.9

CSS & Javascript Compressed by The Yahoo! JavaScript and CSS Compressor (YUI Compressor) v2.4.2
