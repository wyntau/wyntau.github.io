<?php
/**
 * example file
 */

/**
 * A short description of your function
 *
 * @return unknown_type
 */
function iSayme_your_function_name(){
	// you code gose here
}
// filter? just use 'add_filter()'
// add_filter('the_filter_name', 'the_function');

// or you can add a action use 'add_action()'
// add_action('the_action_name', 'the_function');
