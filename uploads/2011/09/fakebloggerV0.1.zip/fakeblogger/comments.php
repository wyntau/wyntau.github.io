<?php
if( post_password_required() ):
?>
<div>
	<?php _e('This post is password protected. Enter the password to view comments.');?>
</div>
<?php return; endif;?>


<!--list comment-->
<?php if( have_comments() ):?>
<ol id="comments">
<?php wp_list_comments(array( 'callback' => 'fakeblogger_comment'));?>
</ol>
<?php else:?>
	<?php _e('No comments yet.'); ?><br />
<?php endif; ?>

<?php  if(comments_open()) : ?>
<div class="commentpost" id="respond">
<p class="posttop">发表评论:</p>
<form action="<?php	echo get_option('siteurl');?>/wp-comments-post.php" method="post" id="commentform">
<?php if ($user_ID):?>
<p>Logged in as <a href="<?php echo get_option('siteurl');?>/wp-admin/profile.php"><?php echo $user_identity;?></a>. <a href="<?php echo get_option('siteurl');?>/wp-login.php?action=logout" title="Log out of this account">Logout &raquo;</a>
</p>
<?php else:?>
<p>	<input type="text" name="author" id="author" value="<?php echo $comment_author;?>" size="40" tabindex="1" />
	<label for="author"><small>Name <?php if ($req) echo "(required)";?></small></label>
</p>
<p>	<input type="text" name="email" id="email" value="<?php echo $comment_author_email;?>" size="40" tabindex="2" />
	<label for="email"><small>Mail (will not be published) <?php if ($req) echo "(required)";?></small></label>
</p>
<p>	<input type="text" name="url" id="url" value="<?php echo $comment_author_url;?>" size="40" tabindex="3" />
	<label for="url"><small>Website</small></label>
</p>
<?php endif;?>
<p>	<textarea name="comment" id="comment" cols="60" rows="10" tabindex="4"></textarea></p>
<p>	<input name="submit" type="submit" id="submit" tabindex="5" value="Submit Comment" />
	<input type="hidden" name="comment_post_ID" value="<?php echo $id;?>" />
</p>
<?php	do_action('comment_form', $post->ID);?>
</form>
<p class="postbottom">◎欢迎参与讨论，请在这里发表您的看法、交流您的观点。</p>
</div>
<?php else:?>
<?php _e( 'Comments are closed.'); ?>
<?php endif;?>
