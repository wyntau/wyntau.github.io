<div id="sidebar"><!--start of sidebar-->
	<div id="sidebartop"> </div>

<?php if( !function_exists('dynamic_sidebar') || !dynamic_sidebar(1) ): ?>
<?php endif;//widget 1?>
<?php if( !function_exists('dynamic_sidebar') || !dynamic_sidebar(2) ): ?>
<?php endif;//widget 1?>
<div class="widget">
	<h3><span>功能</span></h3>
	<ul>
		<?php wp_register(); ?>
		<li><?php wp_loginout(); ?></li>
	</ul>
</div>
<div id="sidebarbottom"> </div>
</div><!--end of sidebar-->
