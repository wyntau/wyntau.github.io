<?php

if ( function_exists('register_nav_menus') ) {
	register_nav_menus(array('primary' => '头部导航栏'));
}
define('SAYME','iSayme');
define('FUNC',TEMPLATEPATH.'/func');
/**
 * include all PHP script
 * @param string $dir
 * @return unknown_type
 */
function iSaymeIncludeAll($dir){
	$dir = realpath($dir);
	if($dir){
		$files = scandir($dir);
		sort($files);
		foreach($files as $file){
			if($file == '.' || $file == '..'){
				continue;
			}elseif(preg_match('/\.php$/i', $file)){
				include_once $dir.'/'.$file;
			}
		}
	}
}
iSaymeIncludeAll( FUNC );

if ( function_exists('register_sidebar') ){
    register_sidebar(array(
        'before_widget' => '<div class="widget">',
        'after_widget' => '</div><div class="clear"></div>',
        'before_title' => '<h3><span>',
        'after_title' => '</span></h3>',
        'name' =>'First'
    ));
    register_sidebar(array(
        'before_widget' => '<div class="widget">',
        'after_widget' => '</div><div class="clear"></div>',
        'before_title' => '<h3><span>',
        'after_title' => '</span></h3>',
        'name' =>'Second'
    ));
}

function fakeblogger_comment($comment, $args, $depth){
	$GLOBALS['comment'] = $comment;
	?>
<li <?php comment_class();?> id="comment-<?php comment_ID();?>">
	<div id="div-comment-<?php comment_ID();?>" class="comment-body">
<div class="comment-author vcard"> <cite class="fn"><?php comment_author_link(); ?></cite><span class="says">&nbsp;说道：</span></div>
<div class="comment-meta commentmetadata"><?php comment_time(__('M jS, Y @ H:i'))?>&nbsp;&nbsp;<?php if($user_ID) edit_comment_link(__('Edit', YHL)); ?></div>
<?php if( ! $comment->comment_approved ): ?>
			<p class="alert"><strong><?php _e('Your comment is awaiting moderation.'); ?></strong></p>
			<?php endif; ?>
			<?php comment_text(); ?>
<div class="reply"><?php comment_reply_link( array_merge( $args, array( 'reply_text' => __( '回复 ' ), 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?><span>&darr;</span></div>
</div>
</li>
<?php
}
