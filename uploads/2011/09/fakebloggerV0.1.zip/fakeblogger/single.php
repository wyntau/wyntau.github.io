<?php get_header();?>
		<div id="content"><!--start of content-->
<?php if(have_posts()): ?>
<?php while(have_posts()):?>
	<?php the_post();?>
<div class="postnav"><!--start of postnav-->
		<?php 
		if (get_previous_post()) { 
			  previous_post_link('<div class="left"><span>&laquo;</span> %link</div>');
 		} else {
    			echo "<div class=\"left\"><span>&laquo;</span> 已经是最后一篇啦</div>";
 		}	
		if (get_next_post()) { 
			  next_post_link('<div class="right">%link <span>&raquo;</span></div>');
 		} else {
    			echo "<div class=\"right\">已经是第一篇啦 <span>&raquo;</span></div>";
 		}		
		?>
	<div class="clear"></div>	
	</div><!--end of postnav-->
<div id="post-<?php the_ID();?>" class="post"><!--start of every post-->
	<h4 class="postdate right"><?php the_time(__('F jS, Y')); ?></h4>
	<h2 class="posttitle"><a href="<?php the_permalink();?>" title="<?php the_title();?>"><?php the_title();?></a></h2>
	<div class="entry"><!--start of entry-->
		<?php the_content();?>
	</div><!--end of entry-->

	<div class="postmeta right"><!--start of postmeta-->
		<?php _e('分类:'); ?> <?php the_category(', ') ?> | <?php _e('发布:'); ?> <?php  the_author(); ?> | 
    		<?php comments_popup_link('No Comments »', '1 Comment »', '% Comments »'); ?> <?php edit_post_link('Edit', ' | ', ''); ?>
	</div><!--end of postmeta-->

</div><!--end of every post-->

<?php endwhile;?>
	<?php comments_template(); ?>
<?php else://if have no posts?>
	<?php _e('Not Found!');?>
<?php endif;?>

		</div><!--end of content-->

<?php get_sidebar();?>

<?php get_footer();?>

	</div><!--end of wrapper-->

</div><!--end of divall-->
</body>
</html>
