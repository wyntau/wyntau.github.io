<div id="footer" class="clear"><!--start of footer-->
	Powered by Wordpress | Copyright &copy; 2011 <?php bloginfo('name');?><sup>&reg;</sup>  | FakeBlogger Coded By <a href="http://isayme.com">iSayme</a> Designed By <a rel="nofollow" href="http://blogger.com">Blogger</a>.
</div><!--end of footer-->
